from flask import Flask, render_template, request, send_from_directory
import os
import subprocess
from datetime import datetime
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['PROCESSED_FOLDER'] = 'processed'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['PROCESSED_FOLDER'], exist_ok=True)

def time_to_seconds(time_str):
    """将 时:分:秒 转换为秒数"""
    h, m, s = map(float, time_str.split(':'))
    return h * 3600 + m * 60 + s

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/process', methods=['POST'])
def process_video():
    # 获取上传文件
    file = request.files['video']
    if not file:
        return "请选择视频文件", 400
    
    # 获取时间参数
    start_time = request.form['start_time']
    end_time = request.form['end_time']
    text = request.form.get('text', '')
    
    try:
        # 保存原始文件
        filename = secure_filename(file.filename)
        input_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(input_path)
        
        # 生成输出文件名
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        output_filename = f"edited_{timestamp}.mp4"
        output_path = os.path.join(app.config['PROCESSED_FOLDER'], output_filename)
        
        # 构建FFmpeg命令 (无损剪切)
        cmd = [
            'ffmpeg',
            '-i', input_path,
            '-ss', start_time,
            '-to', end_time,
            '-c:v', 'copy',
            '-c:a', 'copy',
            output_path
        ]
        
        # 如果需要添加文字
        if text:
            # 使用带滤镜的重新编码方式
            cmd = [
                'ffmpeg',
                '-i', input_path,
                '-ss', start_time,
                '-to', end_time,
                '-vf', f"drawtext=text='{text}':fontfile=/path/to/font.ttf:fontsize=24:fontcolor=white:x=10:y=10",
                '-c:a', 'copy',
                output_path
            ]
        
        # 执行FFmpeg命令
        subprocess.run(cmd, check=True)
        
        return {
            'status': 'success',
            'download_url': f'/download/{output_filename}'
        }
    except Exception as e:
        return {'status': 'error', 'message': str(e)}, 500

@app.route('/download/<filename>')
def download_file(filename):
    return send_from_directory(app.config['PROCESSED_FOLDER'], filename)

if __name__ == '__main__':
    app.run(debug=True)